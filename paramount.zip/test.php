<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
	<link href="css/bootstrap.min.css" type="text/css" rel="stylesheet" media="all">
    <link href="css/style1.css" type="text/css" rel="stylesheet" media="all">
	<link type="text/css" rel="stylesheet" href="mycss.css" />
</head>

<body>
<div class="form-group">
	<div class="row">
		<div class="col-md-62 quotes">
        	Downregulation
        </div>
        <div class="col-md-62 quotes">
        	Downregulation
        </div>
        <div class="col-md-62 quotes">
        	Downregulation
        </div>
        <div class="col-md-62 quotes">
        	Downregulation
		</div>
	</div>
</div>
</body>
</html>
